#Name: Rithik Kapoor
#ID: 1001667604

import math

import numpy as np
import PIL.Image as Image
import matplotlib.pyplot as plt
import scipy.ndimage as ndi
from matplotlib.patches import ConnectionPatch
from skimage.feature import SIFT, match_descriptors
from skimage.color import rgb2gray, rgba2rgb
from skimage.transform import resize, ProjectiveTransform, SimilarityTransform, warp, AffineTransform
from skimage import measure
import sys

def detect_keypoints(img):
    detector1 = SIFT()
    detector1.detect_and_extract(img)
    keypoints1 = detector1.keypoints
    descriptors1 = detector1.descriptors
    return keypoints1, descriptors1

def match_keypoints(desc1, desc2):
    N1 = desc1.shape[0]
    N2 = desc2.shape[0]
    matches = []
    for i in range(N1):
        desc_aug = np.tile(desc1[i], (N2, 1))

        err = desc_aug - desc2
        L2_norm = np.sqrt(np.sum(err*err, axis=1))
        idx = np.argsort(L2_norm)
        if L2_norm[idx[0]] < 1*L2_norm[idx[1]]:
            matches.append([i, idx[0]])
    matches = np.asarray(matches)
    return matches

def calc_affine(src, dst):
    a = []
    b = []
    for i in range(len(src)):
        a.append([src[i, 0], src[i, 1], 1, 0, 0, 0])
        a.append([0, 0, 0, src[i, 0], src[i, 1], 1])
        b.append(dst[i, 0])
        b.append(dst[i, 1])

    #print("\n\n", "//////////////////////////////")
    # print(a, "\n\n", b)
    #x = np.linalg.lstsq(a, b, rcond=None)[0]
    a = np.array(a)
    b = np.array(b)
    lhs = np.linalg.inv(np.matmul(a.T, a))
    rhs = np.matmul(a.T, b)
    x = np.matmul(lhs, rhs)
    x = np.array(x)
    x = np.append(x, [0, 0, 1])
    x = x.reshape((3, 3))
    return x

def calc_projective(src, dst):
    a2 = []
    b2 = []
    for i in range(len(src)):
        a2.append([src[i, 0], src[i, 1], 1, 0, 0, 0, -src[i, 0] * dst[i, 0], -src[i, 1] * dst[i, 0]])
        a2.append([0, 0, 0, src[i, 0], src[i, 1], 1, -src[i, 0] * dst[i, 1], -src[i, 1] * dst[i, 1]])
        b2.append(dst[i, 0])
        b2.append(dst[i, 1])

    #print("\n\n", "//////////////////////////////")
    # print(a, "\n\n", b)
    #x2 = np.linalg.lstsq(a2, b2, rcond=None)[0]
    a2 = np.array(a2)
    b2 = np.array(b2)
    lhs = np.linalg.inv(np.matmul(a2.T, a2))
    rhs = np.matmul(a2.T, b2)
    x2 = np.matmul(lhs, rhs)
    x2 = np.array(x2)
    x2 = np.append(x2, [1])
    x2 = x2.reshape((3, 3))
    return x2

def plot_keypoints(src, dst, src_img, dst_img):
    fig = plt.figure(figsize=(8, 4))
    ax1 = fig.add_subplot(121)
    ax2 = fig.add_subplot(122)
    ax1.imshow(src_img, cmap='gray')
    ax2.imshow(dst_img, cmap='gray')

    for i in range(src.shape[0]):
        coordB = [src[i, 1], src[i, 0]]
        coordA = [dst[i, 1], dst[i, 0]]
        con = ConnectionPatch(xyA=coordA, xyB=coordB, coordsA="data", coordsB="data",
                              axesA=ax2, axesB=ax1, color="red")
        ax2.add_artist(con)
        ax1.plot(src[i, 1], src[i, 0], 'ro')
        ax2.plot(dst[i, 1], dst[i, 0], 'ro')
    plt.show()

def ransac(src, dst, model, n_min, max_iter, thresh):
    bestModel = None
    bestErr = sys.maxsize
    for iter in range(max_iter):
        rand_arr = np.random.permutation(len(src))
        src_inlier = src[rand_arr[0:n_min],:]
        src_outlier = src[rand_arr[n_min:],:]
        dst_inlier = dst[rand_arr[0:n_min],:]
        dst_outlier = dst[rand_arr[n_min:],:]
        # print(src_inlier, "\n\n", src_outlier)
        # print("////////////////////////////////")
        maybeModel = None
        if model == "projective":
            maybeModel = calc_projective(src_inlier, dst_inlier)
        if model == "affine":
            maybeModel = calc_affine(src_inlier, dst_inlier)
        src_alsoInliers = []
        dst_alsoInliers = []
        for i in range(len(src_outlier)):
            err = 0
            if model == "projective":
                err = calc_error_proj(src_outlier[i], dst_outlier[i], maybeModel)
            if model == "affine":
                err = calc_error_affine(src_outlier[i], dst_outlier[i], maybeModel)
            if err < thresh:
                src_alsoInliers.append(src_outlier[i])
                dst_alsoInliers.append(dst_outlier[i])
        #print(src_alsoInliers)
        src_final = np.concatenate((src_inlier, src_alsoInliers), axis=0)
        dst_final = np.concatenate((dst_inlier, dst_alsoInliers), axis=0)
        # src_final = src_inlier + src_alsoInliers
        # dst_final = dst_inlier + dst_alsoInliers
        #print(src_alsoInliers)
        betterModel = None
        if model == "projective":
            betterModel = calc_projective(src_final, dst_final)
        if model == "affine":
            betterModel = calc_affine(src_final, dst_final)
        total_err = 0
        for i in range(len(src)):
            if model == "projective":
                total_err += calc_error_proj(src[i], dst[i], betterModel)
            if model == "affine":
                total_err += calc_error_affine(src[i], dst[i], betterModel)
        if total_err < bestErr:
            bestModel = betterModel
            bestErr = total_err
    return bestModel

def calc_error_proj(src, dst, model):
    x0 = model[0, 0] * src[0] + model[0, 1] * src[1] + model[0, 2] - dst[0] * model[2, 0] * src[0] - dst[0] * model[2, 1] * src[1]
    y0 = model[1, 0] * src[0] + model[1, 1] * src[1] + model[1, 2] - dst[1] * model[2, 0] * src[0] - dst[1] * model[2, 1] * src[1]
    return ((x0 - dst[0]) ** 2 + (y0 - dst[1]) ** 2) ** 0.5

def calc_error_affine(src, dst, model):
    x0 = model[0, 0] * src[0] + model[0, 1] * src[1] + model[0, 2]
    y0 = model[1, 0] * src[0] + model[1, 1] * src[1] + model[1, 2]
    return ((x0 - dst[0]) ** 2 + (y0 - dst[1]) ** 2) ** 0.5

def test(img1_name, img2_name, model):
    src_img_rgb = np.asarray(Image.open(img1_name))
    dst_img_rgb = np.asarray(Image.open(img2_name))

    src_img_rgb2 = Image.open(img1_name)
    dst_img_rgb2 = Image.open(img2_name)

    if dst_img_rgb.shape[2] == 4:
        dst_img_rgb = rgba2rgb(dst_img_rgb)
    if src_img_rgb.shape[2] == 4:
        src_img_rgb = rgba2rgb(src_img_rgb)

    dst_img = rgb2gray(dst_img_rgb)
    src_img = rgb2gray(src_img_rgb)

    src_keypoints, src_descriptors = detect_keypoints(src_img)
    dst_keypoints, dst_descriptors = detect_keypoints(dst_img)

    match = match_keypoints(src_descriptors, dst_descriptors)

    src = src_keypoints[match[:, 0]]
    dst = dst_keypoints[match[:, 1]]

    plot_keypoints(src, dst, src_img, dst_img)
    affine = None
    if model == "affine":
        affine = calc_affine(src, dst)
        #print(affine)

    projective_matrix = None
    if model == "projective":
        projective_matrix = calc_projective(src, dst)
        #print(projective_matrix)

    best_model = ransac(src, dst, model, 10, 10, 20)
    print(best_model)
    sk_M = ProjectiveTransform(best_model)
    #print(sk_M)
    if model == "ransac_affine":
        sk_M, sk_best = measure.ransac((src[:, ::-1], dst[:, ::-1]), AffineTransform, min_samples=4, residual_threshold=1, max_trials=300)
    if model == "ransac_projective":
        sk_M, sk_best = measure.ransac((src[:, ::-1], dst[:, ::-1]), ProjectiveTransform, min_samples=4, residual_threshold=1, max_trials=300)
    rows, cols = dst_img.shape
    corners = np.array([
        [0, 0],
        [cols, 0],
        [0, rows],
        [cols, rows]
    ])

    corners_proj = sk_M(corners)
    all_corners = np.vstack((corners_proj[:, :2], corners[:, :2]))

    corner_min = np.min(all_corners, axis=0)
    corner_max = np.max(all_corners, axis=0)
    output_shape = (corner_max - corner_min)
    output_shape = np.ceil(output_shape[::-1]).astype(int)
    #print(output_shape)

    offset = SimilarityTransform(translation=-corner_min)
    dst_warped = warp(dst_img_rgb, offset.inverse, output_shape=output_shape)

    tf_img = warp(src_img_rgb, (sk_M+offset).inverse, output_shape=output_shape)

    # Combine the images
    foreground_pixels = tf_img[tf_img > 0]
    dst_warped[tf_img > 0] = tf_img[tf_img > 0]

    # Plot the result
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.imshow(dst_warped)
    plt.show()


test("Rainier1.png", "Rainier2.png", "affine")
test("Rainier1.png", "Rainier2.png", "projective")
